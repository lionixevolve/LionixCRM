<?php
$module_name = 'lx_topics';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'level2',
            'label' => 'LBL_LEVEL2',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'level3',
            'label' => 'LBL_LEVEL3',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'level4',
            'label' => 'LBL_LEVEL4',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'level5',
            'label' => 'LBL_LEVEL5',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'level6',
            'label' => 'LBL_LEVEL6',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'level7',
            'label' => 'LBL_LEVEL7',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'comment' => 'Full text of the note',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'procedure1',
            'studio' => 'visible',
            'label' => 'LBL_PROCEDURE1',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'escalation',
            'label' => 'LBL_ESCALATION',
          ),
        ),
      ),
    ),
  ),
);
?>
