<?php
$module_name = 'lx_topics';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'level2' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL2',
        'width' => '10%',
        'default' => true,
        'name' => 'level2',
      ),
      'level3' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL3',
        'width' => '10%',
        'default' => true,
        'name' => 'level3',
      ),
      'level4' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL4',
        'width' => '10%',
        'default' => true,
        'name' => 'level4',
      ),
      'level5' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL5',
        'width' => '10%',
        'default' => true,
        'name' => 'level5',
      ),
      'level6' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL6',
        'width' => '10%',
        'default' => true,
        'name' => 'level6',
      ),
      'level7' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL7',
        'width' => '10%',
        'default' => true,
        'name' => 'level7',
      ),
      'escalation' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ESCALATION',
        'width' => '10%',
        'name' => 'escalation',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'level2' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL2',
        'width' => '10%',
        'default' => true,
        'name' => 'level2',
      ),
      'level3' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL3',
        'width' => '10%',
        'default' => true,
        'name' => 'level3',
      ),
      'level4' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL4',
        'width' => '10%',
        'default' => true,
        'name' => 'level4',
      ),
      'level5' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL5',
        'width' => '10%',
        'default' => true,
        'name' => 'level5',
      ),
      'level6' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL6',
        'width' => '10%',
        'default' => true,
        'name' => 'level6',
      ),
      'level7' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_LEVEL7',
        'width' => '10%',
        'default' => true,
        'name' => 'level7',
      ),
      'escalation' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_ESCALATION',
        'width' => '10%',
        'name' => 'escalation',
      ),
      'description' => 
      array (
        'type' => 'text',
        'label' => 'LBL_DESCRIPTION',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'description',
      ),
      'procedure1' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_PROCEDURE1',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'procedure1',
      ),
      'procedure2' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_PROCEDURE2',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'procedure2',
      ),
      'procedure3' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_PROCEDURE3',
        'sortable' => false,
        'width' => '10%',
        'default' => true,
        'name' => 'procedure3',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
