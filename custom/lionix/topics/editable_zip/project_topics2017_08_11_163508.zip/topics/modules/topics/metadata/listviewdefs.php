<?php
$module_name = 'lx_topics';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'LEVEL2' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL2',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL3' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL3',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL4' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL4',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL5' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL5',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL6' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL6',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL7' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL7',
    'width' => '10%',
    'default' => true,
  ),
  'ESCALATION' => 
  array (
    'type' => 'bool',
    'default' => true,
    'label' => 'LBL_ESCALATION',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
?>
