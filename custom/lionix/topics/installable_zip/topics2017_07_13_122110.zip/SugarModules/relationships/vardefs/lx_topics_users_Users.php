<?php
// created: 2017-07-13 12:21:10
$dictionary["User"]["fields"]["lx_topics_users"] = array (
  'name' => 'lx_topics_users',
  'type' => 'link',
  'relationship' => 'lx_topics_users',
  'source' => 'non-db',
  'module' => 'lx_topics',
  'bean_name' => 'lx_topics',
  'vname' => 'LBL_LX_TOPICS_USERS_FROM_LX_TOPICS_TITLE',
);
