<?php
 // created: 2017-07-13 12:26:43
$layout_defs["lx_topics"]["subpanel_setup"]['lx_topics_users'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LX_TOPICS_USERS_FROM_USERS_TITLE',
  'get_subpanel_data' => 'lx_topics_users',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
