<?php
// created: 2017-07-13 12:26:43
$dictionary["lx_topics"]["fields"]["lx_topics_users"] = array (
  'name' => 'lx_topics_users',
  'type' => 'link',
  'relationship' => 'lx_topics_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_LX_TOPICS_USERS_FROM_USERS_TITLE',
);
