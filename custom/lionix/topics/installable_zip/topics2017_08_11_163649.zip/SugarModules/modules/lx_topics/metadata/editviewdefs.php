<?php
$module_name = 'lx_topics';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'level2',
            'label' => 'LBL_LEVEL2',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'level3',
            'label' => 'LBL_LEVEL3',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'level4',
            'label' => 'LBL_LEVEL4',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'level5',
            'label' => 'LBL_LEVEL5',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'level6',
            'label' => 'LBL_LEVEL6',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'level7',
            'label' => 'LBL_LEVEL7',
          ),
        ),
        7 => 
        array (
          0 => 'description',
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'procedure1',
            'studio' => 'visible',
            'label' => 'LBL_PROCEDURE1',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'procedure2',
            'studio' => 'visible',
            'label' => 'LBL_PROCEDURE2',
          ),
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'procedure3',
            'studio' => 'visible',
            'label' => 'LBL_PROCEDURE3',
          ),
        ),
      ),
    ),
  ),
);
?>
